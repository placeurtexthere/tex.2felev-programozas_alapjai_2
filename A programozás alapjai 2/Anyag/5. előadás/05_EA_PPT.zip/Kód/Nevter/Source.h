#pragma once
namespace mylib {

	void sort(int* eleje, int* vege);
	class string {
	public:
		void print();
	};

}