#include <stdio.h>
#include <iostream>
#include "Source.h"

void mylib::string::print()
{
	//...
}
