﻿#include <iostream>
#include "animal.h"
#include "bunny.h"
#include "string.h"

using namespace std;
using TheUltimateString::String;

void animalTest()
{
	cout << "=== ANIMAL TEST ===" << endl;

	// Animal a = 5; // Ez ne működjön

	Bunny *bunny = new Bunny(4, "bunny");

	Animal *animal = dynamic_cast<Animal*>(bunny);

	if (animal)
		cout << animal->getAge() << endl; // 4

	String *str = new String("bunny");
	//animal = dynamic_cast<Animal*>(str); // Ha jól csináltad, már tervezési időben panaszkodni fog, hogy nem polimorfak.

	animal = reinterpret_cast<Animal*>(str); // bit-wise copy
	str = reinterpret_cast<String*>(animal); // vissza stringgé; ugyanazt kapjuk vissza
	cout << static_cast<const char*>(*str) << endl; // bunny
	cout << *str << endl; // bunny

	const Bunny* cBunny = new Bunny(10, "Izidor");
	cout << cBunny->getName() << endl; // Izidor

									   // cBunny->setName("Dijkstra") // Ha jól csináltad, nem látszódik a setName(...)
	const_cast<Bunny*>(cBunny)->setName("Dijkstra");

	cout << cBunny->getName() << endl; // Dijkstra

	delete bunny;
	delete str;
	delete cBunny;
}
