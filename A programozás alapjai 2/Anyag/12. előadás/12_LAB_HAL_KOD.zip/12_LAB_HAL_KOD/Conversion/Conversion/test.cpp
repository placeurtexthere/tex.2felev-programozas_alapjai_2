#include <iostream>

extern void stringTest();
extern void animalTest();

int main()
{
	stringTest();
	//animalTest();

	std::cin.get();

	return 0;
}