#pragma once
#include <string>
#include <fstream>
#include "serializable.h"

namespace PersistenceAPI
{
	class Loader
	{
		std::string inFileName;
		std::ifstream ifs;
	public:
		// inFileName: annak a f�jlnak az el�r�si �tvonala, ahonnan bet�lti az item-et.
		Loader(std::string inFileName);

		// Megh�vja a param�ter�l kapott item deserialize(...) met�dus�t.
		bool load(Serializable& item);

		// Lez�rja az ifs-t.
		void close();
	};
}