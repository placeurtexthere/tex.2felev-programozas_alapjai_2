#pragma once
#include <string>
#include <fstream>
#include "serializable.h"

namespace PersistenceAPI
{
	class Saver
	{
		std::string outFileName;
		std::ofstream ofs;
	public:
		// outFileName: annak a f�jlnak az el�r�si �tvonala, ahova lementi az item-et.
		Saver(std::string outFileName);

		// Megh�vja a param�ter�l kapott item serialize(...) met�dus�t.
		bool save(Serializable& item);

		// Lez�rja az ofs-t.
		void close();
	};
}
