#include "vikworldPrint.h"

void vikworld()
{
	printf("VIK World!\n");
}