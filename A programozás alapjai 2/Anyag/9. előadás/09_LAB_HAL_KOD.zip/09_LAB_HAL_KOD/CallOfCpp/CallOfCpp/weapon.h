#pragma once
#include <string>
#include <iostream>

class Weapon
{
protected:
	unsigned damage; // sebz�s
public:
	Weapon(unsigned damage);

	~Weapon();

	unsigned getDamage() const;
	void setDamage(unsigned damage);

	unsigned use(); // visszaadja a cs�kkentett sebz�st

	std::string toString() const;
};

std::ostream& operator<<(std::ostream&, const Weapon*);