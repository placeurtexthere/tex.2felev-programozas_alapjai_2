#include <sstream>
#include <iostream>
#include "weapon.h"

using namespace std;

Weapon::Weapon(unsigned damage) : damage(damage) {}

unsigned Weapon::getDamage() const
{
	return damage;
}

unsigned Weapon::use()
{
	return --damage;
}

void Weapon::setDamage(unsigned damage) {
	if (damage <= 100)
		this->damage = damage;
}

string Weapon::toString() const
{
	stringstream ss;
	ss << "Weapon; damage can be caused=" << getDamage();
	return ss.str();
}

ostream& operator<<(ostream& os, const Weapon* right)
{
	// Ha nem nullptr-re mutat� weapont szeretn�nk ki�ratni.
	if (right)
		os << right->toString();
	else os << "no weapon";
	return os;
}
