#pragma once
#include "weapon.h"

class Railgun : public Weapon
{
	unsigned energy; // l�v�shez sz�ks�ges energia: [0;100]
public:
	Railgun(unsigned damage = 90, unsigned energy = 100);

	unsigned getEnergy() const;

	unsigned use();
	void recharge(); // fegyver felt�lt�se

	std::string toString() const;
};

